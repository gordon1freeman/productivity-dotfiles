# opencode — контекст рабочего сетапа (kir)

Этот файл — память для будущих сессий. Здесь вся совместная работа с пользователем
`kir`: что настроено, как устроено, что сломано/выяснено, что дальше.

## Среда
- **Система**: CachyOS (Arch-based), ядро cachyos. **Планируется переезд на EndeavourOS**.
- **Оконный менеджер**: Hyprland **0.56.2** (важно: конфиг теперь **Lua**-файл, не hyprland.conf).
- **Тема**: Everforest Dark Hard. Монитор eDP-1 1920x1200@120, scale 1. Раскладка us,ru + `grp:alt_shift_toggle`.
- **Философия пользователя**: «если не улучшает продуктивность — оно не нужно». Минимализм, keyboard-first.

## Карта конфигов
| Путь | Что это |
|---|---|
| `~/.config/hypr/hyprland.lua` | **Главный конфиг** Hyprland (Lua API 0.56): binds, rules, autostart, env |
| `~/.config/hypr/hypridle.conf` | idle/lock (suspend-листенер закомментирован) |
| `~/.config/hypr/hyprlock.conf` | локскрин (Everforest, время по центру) |
| `~/.config/hypr/hyprpaper.conf` | обои: `/home/kir/Pictures/so larp.jpg` (не перенесён в миграцию!) |
| `~/.config/hypr/scripts/toggle-float.sh` | generic-toggle плавающих окон: `toggle-float.sh <class> <cmd...>` |
| `~/.config/hypr/scripts/window-switch.sh` | SUPER+TAB, переключение окон |
| `~/.config/waybar/config.jsonc` | панель: clock, workspaces, tray, window, updates, temp, mem, cpu, audio, battery, power-mode, network, powermenu |
| `~/.config/waybar/scripts/power-mode*.sh` | индикатор/цикл профилей питания (signal 8, `return-type: json`) |
| `~/.config/wlogout/layout` | меню выключения — файл **без расширения** |
| `~/.config/fish/config.fish` | fish + блок автологина tty1→uwsm в начале + zoxide/fzf/prompt/fastfetch |
| `~/.config/kitty/kitty.conf` + `themes/noctalia.conf` | терминал, `current-theme.conf` → symlink на тему |
| `~/.config/mako/config` | уведомления |
| `~/.config/fastfetch/` | приветствие в терминале |
| `~/notes.md` | заметки (SUPER+N) |

## Горячие клавиши (сводка)
- `SUPER+Enter` kitty · `SUPER+W` zen-browser · `SUPER+E` nautilus · `SUPER+Q` close · `SUPER+F` fullscreen
- `SUPER+Space`/`SUPER+R` wofi · `SUPER+TAB` window-switch · `SUPER+V` cliphist
- `SUPER+N` **заметки** (micro на `~/notes.md`, плавающее окно 60%x60% по центру)
- `SUPER+ё` (grave) **дропдаун-терминал** (kitty во всю ширину, 100%x30%, сверху)
- `SUPER+L` hyprlock · `SUPER+M` wlogout · `Print`/`CTRL+Print` скриншот всего/области
- `XF86Audio*` wpctl · `XF86MonBrightness*` brightnessctl · `XF86AudioNext/Pause/Prev` playerctl
- Workspaces SUPER+1..0, переключение/перемещение стрелками + SHIFT

## История работ (хронология сессий)
1. **wlogout починен**: корень — wlogout 1.2.2 читает `layout` **без расширения**
   (наш `layout.json` игнорировался), брал системный `/etc/wlogout/layout` со swaylock и
   сломанным `hyprctl dispatch exit 0`. Создан `~/.config/wlogout/layout` (2 кнопки:
   shutdown/reboot). Призрачная 3-я кнопка — баг сетки wlogout → фикс флагом **`-b 2`**
   (в бинде SUPER+M и в on-click waybar).
2. **Waybar**: убран bluetooth-модуль (остался в трее), добавлен `custom/power-mode`
   (power-profiles-daemon), `"return-type": "json"` обязателен (иначе сырой JSON),
   уменьшен format-icons.
3. **Оптимизация запуска (~20с до рабочего стола, подтверждено)**: GRUB_TIMEOUT 5→1
   (меню остаётся для Windows), initrd `MODULES=(nvme)` + `COMPRESSION="lz4"`,
   mask `NetworkManager-wait-online`, disable `zapret2 sddm warp-svc HiddifyTunnelService`,
   автологин `kir` на tty1 → `exec uwsm start hyprland.desktop` (гард в начале
   `config.fish`). Скрипт сохранён: **`~/opt.sh`** (root, запускать пользователю через sudo).
4. **Продуктивность (последняя ветка)**: SUPER+N/SUPER+ё/Print/CTRL+Print + window rules
   для notes/dropdown. Починен баг двойного `date` в CTRL+Print (общая переменная `$F`).
5. **Миграция на EndeavourOS**: собран **`~/migration-hypr/`** (configs.tar.gz + install.sh
   + README.md + notes.md). Обновил бекап-конфиги.

## Технические грабли Hyprland 0.56 (Lua) — экономит часы
- **`hyprctl dispatch closewindow "address:0x..."` СЛОМАН**: аргумент парсится как Lua
  → ошибка `')' expected`. Рабочая замена: `hyprctl dispatch 'hl.dsp.window.close({ window = "class:notes" })'`.
  Аналогично `kill`: `hl.dsp.window.kill(...)`.
- **`size` window rule**: значения — expression vec2, только формат
  `"monitor_w*0.6 monitor_h*0.6"`. Проценты `"60% 60%"` не работают. Для плавающих окон
  работает только через правила float+size+center/move (см. hyprland.lua).
- **Диспетчеры через `__lua`**: в `hyprctl binds` ключи выглядят как `N -> __lua` — это норма.
- Легаси `hyprctl dispatch exit 0` сломан → `hl.dsp.exit()`. DPMS → `hl.dsp.dpms(true)`.
- **micro держит окно при graceful close** → в toggle-float.sh fallback: `close` → 0.5с → `kill`.

## Другие грабли
- **wlogout**: `layout` без расширения; `-b 2` для 2 кнопок (баг сетки).
- **Waybar 0.15**: custom-модуль без `"return-type": "json"` показывает сырой JSON.
- **fish на EndeavourOS**: удалить `source /usr/share/cachyos-fish-config/cachyos-config.fish`
  (CachyOS-специфично) — иначе fish ругается. Блок автологина НЕ трогать.
- **Автологин** — системное (вне .config): getty@tty1 override + `uwsm start hyprland.desktop`.
- **power-profiles-daemon** + amd-pstate-epp; профиль сейчас `balanced`.
- **sudo требует пароль** — корневые действия только скриптами, которые пользователь
  запускает сам (`sudo bash ~/opt.sh`).

## Миграция на EndeavourOS — состояние
- Папка **`~/migration-hypr/`**: `configs.tar.gz` (hypr/waybar/wlogout/fish/kitty/mako/fastfetch),
  `install.sh` (repo+AUR: hyprland-стек, grim/slurp/wl-clipboard/cliphist, pipewire,
  парu, zen-browser-bin, bibata-cursor-theme и т.д.), `README.md`, `notes.md`.
- Старый бекап `~/config-backup/2026-08-14/` (включая `system/` — grub/mkinitcpio) остаётся на диске.

## Ближайшие задачи (что дальше)
1. **[ПОСЛЕ установки EndeavourOS]** настройка автологина tty1→uwsm (пользователь сказал:
   «сделаем после того как всё установлю»). Заготовка — блок в `config.fish`, системный
   скрипт по мотивам `~/opt.sh` (grub/mkinitcpio/wait-online под EndeavourOS).
2. Проверить `hyprctl version` ≥ 0.56 на новой системе (нужен Lua-конфиг).
3. Обои: hyprpaper.conf ссылается на `~/Pictures/so larp.jpg` — на новой системе файла нет,
   пользователь положит свою или поменять путь.
4. Открытый вопрос из прошлого: **suspend (s2idle) не проверен** — при желании проверить,
   реально ли ноутбук засыпает.
5. Приоритет пользователя — продуктивность: предлагать только то, что ускоряет работу.

## Соглашения
- Общение с пользователем — на **русском**.
- Валидировать hyprland.lua: `luac -p ~/.config/hypr/hyprland.lua` + `hyprctl reload`
  (применение), проверка биндов `hyprctl binds`.
- Не коммитить без явной просьбы. sudo-пароля нет — не выполнять root-команды напрямую.
