#!/bin/bash
mode=$(powerprofilesctl get)
case "$mode" in
    performance) echo '{"text":"󰓅","tooltip":"Производительность"}';;
    balanced) echo '{"text":"󰾅","tooltip":"Стандарт"}';;
    power-saver) echo '{"text":"󰾆","tooltip":"Энергосбережение"}';;
    *) echo '{"text":"󰾅","tooltip":"'$mode'"}';;
esac
