#!/bin/bash
set -euo pipefail

echo "##############################"
echo "#  УСТАНОВКА ПАКЕТОВ (Arch)  #"
echo "##############################"

if [ "$(id -u)" -eq 0 ]; then
    echo "ОШИБКА: не запускай от root — скрипт сам вызовет sudo."
    exit 1
fi

echo "==> [1/4] Обновление системы"
sudo pacman -Syu --noconfirm

# --- AUR-хелпер (нужен paru — на него ссылается модуль обновлений в waybar) ---
AUR_HELPER=""
if command -v paru >/dev/null 2>&1; then
    AUR_HELPER=paru
elif command -v yay >/dev/null 2>&1; then
    AUR_HELPER=yay
fi

if [ -z "$AUR_HELPER" ]; then
    echo "==> Устанавливаю paru из AUR..."
    sudo pacman -S --needed --noconfirm base-devel rust git
    git clone --depth 1 https://aur.archlinux.org/paru.git /tmp/paru
    (cd /tmp/paru && makepkg -si --noconfirm)
    AUR_HELPER=paru
fi
echo "AUR-хелпер: $AUR_HELPER"

# --- Репозиторные пакеты ---
REPO="
  hyprland hypridle hyprlock hyprpaper uwsm
  xdg-desktop-portal-hyprland xdg-desktop-portal-gtk
  waybar wlogout wofi mako
  kitty micro fish fisher
  grim slurp wl-clipboard cliphist
  pipewire wireplumber pipewire-pulse pipewire-audio pipewire-alsa
  pavucontrol pamixer playerctl
  brightnessctl power-profiles-daemon polkit-kde-agent
  networkmanager bluez bluez-utils blueman pacman-contrib
  nautilus gvfs gvfs-mtp
  ttf-jetbrains-mono-nerd ttf-hack ttf-meslo-nerd
  noto-fonts noto-fonts-emoji noto-fonts-cjk
  jq bat eza fzf ripgrep fd zoxide fastfetch
"

echo "==> [2/4] Установка репозиторных пакетов"
sudo pacman -S --needed --noconfirm $REPO

# --- AUR-пакеты ---
echo "==> [3/4] Установка AUR-пакетов"
# zen-browser-bin — браузер из hyprland.lua (SUPER+W)
# bibata-cursor-theme — курсор Bibata-Modern-Ice (в конфиге hyprland)
# networkmanager-dmenu-git — раскомментируй, если нужен wifi-меню через dmenu
$AUR_HELPER -S --needed --noconfirm paru zen-browser-bin bibata-cursor-theme
#$AUR_HELPER -S --needed --noconfirm networkmanager-dmenu-git

# --- fish-плагины (опционально) ---
echo "==> [4/4] fish-плагины (опционально)"
if command -v fisher >/dev/null 2>&1; then
    fish -c "fisher install jorgebucaran/autopair.fish pure-fish/pure" 2>/dev/null \
        || echo "    пропущено — позже: fish -c 'fisher install autopair pure'"
fi

echo ""
echo "========================================"
echo "Пакеты установлены. Дальше по README.md"
echo "========================================"
