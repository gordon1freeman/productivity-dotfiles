# Миграция на EndeavourOS

Переезд конфигов продуктивного сетапа (Hyprland 0.56 + Lua-конфиг, Everforest Dark Hard).

## Состав папки
| Файл | Назначение |
|---|---|
| `configs.tar.gz` | Все конфиги (hypr, waybar, wlogout, fish, kitty, mako, fastfetch) |
| `install.sh` | Установка всех пакетов (repo + AUR) |
| `notes.md` | Заметки (SUPER+N) |
| `AGENTS.md` | Память opencode (наша история работ) — положить в `~/.config/opencode/` |
| `README.md` | Этот файл |

## 1. Установка пакетов
```bash
chmod +x install.sh
./install.sh          # спросит sudo, ставит всё сам
```
AUR-хелпер (`paru`) нужен обязательно — на него ссылается модуль обновлений в waybar.

## 2. Развёртывание конфигов
```bash
tar -xzf configs.tar.gz -C ~/.config
cp notes.md ~/notes.md
mkdir -p ~/Pictures/screenshots    # сюда grim складывает скриншоты
mkdir -p ~/.config/opencode && cp AGENTS.md ~/.config/opencode/AGENTS.md   # память opencode
```

## 3. ОБЯЗАТЕЛЬНО после развёртывания

### fish — убрать CachyOS-строку
В `~/.config/fish/config.fish` удалить строку:
```fish
source /usr/share/cachyos-fish-config/cachyos-config.fish
```
Она специфична для CachyOS, на EndeavourOS сломает fish. Строка идёт **после** блока
автологина (`if test -z "$WAYLAND_DISPLAY" ...`) — блок автологина не трогать, он нужен
для входа без дисплей-менеджера.

### Курсор Bibata
Установлен из AUR. Проверка: `hyprctl setcursor Bibata-Modern-Ice 24` (уже в конфиге автозапуском).

### Обои
`hyprpaper.conf` ссылается на `/home/kir/Pictures/so larp.jpg` (свой файл не переносили).
Положи свою картинку на этот путь или поменяй путь в конфиге.

## 4. Важные заметки

- **Версия Hyprland**: конфиг `hyprland.lua` требует **Hyprland ≥ 0.56** (новый Lua-менеджер
  конфигов). Из репозитория Arch ставится актуальная — проверь после установки:
  `hyprctl version`. Если вдруг старая — `sudo pacman -Syu` до 0.56+.
- **wlogout**: конфиг лежит в `~/.config/wlogout/layout` **без расширения** (это важно,
  `.json` игнорируется). В меню 2 кнопки (shutdown/reboot) + кнопка питания в waybar.
- **Скрипты** уже исполняемые: `hypr/scripts/toggle-float.sh`, `hypr/scripts/window-switch.sh`,
  `waybar/scripts/power-mode*.sh`. Если права потерялись: `chmod +x ~/.config/hypr/scripts/* ~/.config/waybar/scripts/*`.
- **`hyprtoolkit.conf`** не переносили (CachyOS-инструмент).
- **waybar** собран на `return-type: json` (power-mode) — нужен waybar ≥ 0.15.0.
- **Автологин + uwsm** (вход без дисплей-менеджера, ~20с до рабочего стола) — делаем
  отдельно после установки, скриптом под root. Блок в `config.fish` уже готов.

## 5. Горячие клавиши (сводка)
| Клавиша | Действие |
|---|---|
| SUPER+Enter | терминал (kitty) |
| SUPER+W | браузер (zen) |
| SUPER+E | файлы (nautilus) |
| SUPER+Space / SUPER+R | wofi-лаунчер |
| SUPER+V | история буфера (cliphist) |
| SUPER+N | заметки (micro, ~/notes.md) |
| SUPER+ё | дропдаун-терминал |
| SUPER+L | локскрин (hyprlock) |
| SUPER+M | меню выключения (wlogout) |
| Print / CTRL+Print | скриншот всего экрана / области |
| XF86Audio* | громкость (wpctl) |
| XF86MonBrightness* | яркость (brightnessctl) |
